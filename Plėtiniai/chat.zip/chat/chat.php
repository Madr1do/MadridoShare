<?php
include '../../sidemenu.php';

if(isset($_GET['logout'])){

	//Simple exit message

	session_destroy();
	header("Location: chatas"); //Redirect the user
}

$_SESSION['name'] = $username;

?>

    <head>

			<style>

			#ekranas {
			  height: 100%;
			  overflow: auto;
				bottom:     0;
			}

			.laikas {
			  font-size: 10px
			}

			.vardas {
				font-size: 10px;
				font-style: italic;
				padding: 3px 10px 3px 10px;
				background-color: 658feb;
				color: white;
				border-radius: 5px;
				margin-bottom: 1rem;
			}

			.stulpelis {
			  float: left;
			  width: 98%;
				margin-top: 1rem;
				margin-bottom: 2rem;
			}

			.eilute{
				background-color: #deebff;
		    padding: 10px 10px 15px 10px;
		    margin-bottom: -10px;
			}

			</style>

    </head>

    <body>

        <div style='height: 60vh' class='card94'>

					<div id="ekranas">

            <?php
            if(file_exists("log.html") && filesize("log.html") > 0){
                $contents = file_get_contents("log.html");
                echo $contents;
            }
            ?>


        	</div>

				</div>
				<form method="POST" style='margin-top: 3rem' name="message" action="">
						<input name="zinute" class='ivedimas' style='margin-right: 5px; margin-top: 2px' type="text" id="zinute" />
						<input name="rasyti" class='button' type="submit" id="rasyti" value="Siųsti" />
				</form>

					<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	        <script type="text/javascript">

				/*	jQuery(document).ready(function() {
					    jQuery("#rasyti").hide();
					});

					jQuery("#zinute").change(function() {
					    if(this.value.replace(/\s/g, "") === "") {
					       jQuery("#rasyti").hide();
					    } else {
					       jQuery("#rasyti").show();
					    }
					});

					*/


            // jQuery Document
            $(document).ready(function () {
                $("#rasyti").click(function () {
                    var clientmsg = $("#zinute").val();
                    $.post("post.php", { text: clientmsg });
                    $("#zinute").val("");
                    return false;
                });

                function loadLog() {
                    var oldscrollHeight = $("#ekranas")[0].scrollHeight - 20; //Scroll height before the request

                    $.ajax({
                        url: "log.html",
                        cache: false,
                        success: function (html) {
                            $("#ekranas").html(html); //Insert chat log into the #ekranas div

                            //Auto-scroll
                            var newscrollHeight = $("#ekranas")[0].scrollHeight - 20; //Scroll height after the request
                            if(newscrollHeight > oldscrollHeight){
                                $("#ekranas").animate({ scrollTop: newscrollHeight }, 'normal'); //Autoscroll to bottom of div
                            }
                        }
                    });
                }

                setInterval (loadLog, 1000);
            });

        </script>
    </body>
</html>
