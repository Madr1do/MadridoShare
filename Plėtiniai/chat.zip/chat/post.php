<?php
session_start();

if(isset($_SESSION['name'])){
    $text = $_POST['text'];

	$text_message = "<div class='stulpelis'>
                      <div class='eilute'>
                        <span class='vardas'>".$_SESSION['name']."</span>
                        <span class='laikas'>".date('m-d')."</span>
                        <span class='laikas'>".date('G:i')."</span>
                      </div>
                      <hr>
                      <span style='margin-top: 1rem;'>".stripslashes(htmlspecialchars($text))."</span><br>
                    </div>";

    file_put_contents("log.html", $text_message, FILE_APPEND | LOCK_EX);
}
?>
