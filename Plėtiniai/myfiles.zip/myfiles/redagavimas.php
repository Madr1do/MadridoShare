<?php

include '../../sidemenu.php';
$direktorija = '../../files/'.$_SESSION['id'].'/';

if(isset($_POST['redaguoti_faila']) && $_POST['failo_pavadinimas'] != 'Pasirinkti' )
{
 $failo_pavadinimas=$_POST['failo_pavadinimas'];
 $rasyti=$_POST['edit_text'];
 $ext=".txt";
 $failo_pavadinimas=$direktorija."".$failo_pavadinimas."".$ext;
 $redaguoti_faila = fopen($failo_pavadinimas, 'w');

 fwrite($redaguoti_faila, $rasyti);
 fclose($redaguoti_faila);

 echo "<script> location.href='../myfiles/myfiles'; </script>";
         exit;

}

if($_POST['failo_pavadinimas'] == 'Pasirinkti' )
{
  echo "<script> location.href='../myfiles/myfiles'; </script>";
          exit;
}

?>
