<?php
include '../../sidemenu.php';
$direktorija = '../../files/'.$_SESSION['id'].'/';

?>
<style>
.ivedimas{
  width: 100%;
}
.atstumas{
  margin-right: 10px;
}
.virsus{
  padding-top: 3rem;
}

@media only screen and (max-width: 800px){

  .atstumas{
    margin-right: 0px;
  }

  .virsus{
    padding-top: 1rem;
  }

}

</style>
<meta charset="UTF-8">
<form class='virsus' action="" method="POST">
    <h3 name="pavadinimas" type="text" placeholder="Dokumento pavadinimas"/>Naujas Failas</h3>
    <input style="font-family: 'Poppins'" class="ivedimas" name="pavadinimas" type="text" placeholder="Dokumento pavadinimas"/>
    <textarea style="font-family: 'Poppins'; margin-top: 2rem; height: 15rem" rows='4' class="ivedimas" name="turinys" placeholder="Dokumento turinys"/></textarea>
    <input style="margin-top: 2rem; float: right" class="button" type="submit" name="submit" value="Išsaugoti">
    <button class='button atstumas' style='margin-bottom: 20px; margin-top: 2rem; text-decoration: none; float: right' onclick="location.href='myfiles'" type='button'>Atgal</button>

</form>

<?php
  if(isset($_POST['pavadinimas']) && isset($_POST['turinys'])) {
      $data = $_POST['turinys'] . "\r\n";
      $ret = file_put_contents($direktorija. '/' . $_POST['pavadinimas'] . '.txt', $data, FILE_APPEND | LOCK_EX);


      if($ret === false) {
          die('Klaida');
      }
      else {
      }
      echo "<script> location.href='myfiles'; </script>";
              exit;
  }
  else {
  }

?>
