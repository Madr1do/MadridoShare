<?php
include '../../sidemenu.php';
$direktorija = '../../files/'.$_SESSION['id'].'/';

?>
<style>

.stulp {
  float: left;
  width: 49%;
}

.mygtukas1{
  margin-top: 21px;
  text-align: right;
  padding-right: 10px;

}

/* Clear floats after the columns */
.eilute {
  content: "";
  display: table;
  clear: both;
  width: 97%;
  word-wrap: break-word;
  background-color: #fff;
  background-clip: border-box;
  border: 1px solid #e3e6f0;
  border-radius: 10px;
  box-shadow: rgb(149 157 165 / 20%) 0px 8px 24px;
  padding: 1rem 1rem 1rem 2rem;
  border-left: 5px solid #658feb;
  transition: 300ms;
  cursor: auto;
  padding: 0rem 0rem 0rem 1rem;
}

@media only screen and (max-width: 400px){

  h4{
    font-size: 12px;
  }

  .stulp {
    width: 100%;
  }

  .mygtukas1{
    margin-bottom: 20px;
    margin-top: 60px;
    text-align: center;
  }

  .eilute{
    width: 93%;
  }

  .prapletimas{
    max-width: 92%;
  }

}

@media only screen and (min-width: 400px) and (max-width: 800px){

  .prapletimas{
    max-width: 96%;
  }
  .eilute{
      width: 95%;
  }

}
</style>


<?php
$target_file = $direktorija . basename($_FILES["files"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {

  // Check if file already exists
  if (file_exists($target_file)) {
    echo "Failas su tokiu pavadinimu jau egzistuoja.";
    $uploadOk = 0;
  }

  // Check if $uploadOk is set to 0 by an error
  if ($uploadOk == 0) {
    echo " Klaida.";
  // if everything is ok, try to upload file
  } else {
    if (move_uploaded_file($_FILES["files"]["tmp_name"], $target_file)) {
    } else {
    }
  }

}

?>

<!DOCTYPE html>
<html>
<body>

<form action="" method="post" enctype="multipart/form-data">

  <div class='card94' style='text-align: center; margin-right: 1rem; padding-top: 2rem; padding-bottom: 2rem; margin-bottom: 2rem'>

    <label style="margin-bottom: 10px; display: inline-block; cursor: pointer" class='prapletimas button' for="files">Įkelti Failą</label>
    <input style='margin-bottom: 10px;' class='button' type="submit" value="Išsaugoti Failą" name="submit">
    <button class='button' style='text-decoration: none' onclick="location.href='create.php'" type='button'>Sukurti Failą</button>
    <input style="display: inline-block; width: 0px; visibility:hidden;" type="file" id="files" name="files" />

  </div>

</form>


<?php

if (file_exists($direktorija)) {

  $files = scandir($direktorija);
  $files = array_diff(scandir($direktorija), array('.', '..'));
  $type=Array(1 => 'jpg', 2 => 'jpeg', 3 => 'png', 4 => 'txt', 5 => 'pdf');

  $tekstiniai = array();


  foreach($files as $file){

    $ext = explode(".",$file);
    $ext2 = substr(strrchr($file, '.'), 1);

    if(!(in_array($ext[1],$type)))
    {
      echo "

      <div class='eilute'>
        <div class='stulp'>
          <div style='display: inline-block'><i style='margin-right: 5px; font-size: 1.2rem; color: #7F7FD5' class='fas fa-file'></i></div>
          <div style='display: inline-block'><a style='text-decoration: none' href='$direktorija$file' target='_blank'><h4 style='color: black'>$file</h4></a></div>
        </div>
        <div class='mygtukas1'>
          <a class='button' style='margin-left: 5px; text-decoration: none;' href='$direktorija$file' download >Atsisiųsti</a>
        </div>
      </div>

      <br>";
    }

    elseif($ext2 == 'txt')
    {
      $beext = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file);

      array_push($tekstiniai, "$beext");

      echo "

      <div class='eilute'>
        <div class='stulp'>
          <div style='display: inline-block'><i style='margin-right: 5px; font-size: 1.2rem; color: #7F7FD5' class='fas fa-file'></i></div>
          <div style='display: inline-block'><a style='text-decoration: none' target='_blank'><h4 style='color: black'>$file</h4></a></div>
        </div>
        <div class='mygtukas1'>
          <a class='button' style='margin-left: 5px; text-decoration: none;' href='$direktorija$file' download >Atsisiųsti</a>
        </div>
      </div>

      <br>";

    }



    else{

      echo "

      <div class='eilute'>
        <div class='stulp'>
          <div style='display: inline-block'><i style='margin-right: 5px; font-size: 1.2rem; color: #7F7FD5' class='fas fa-file'></i></div>
          <div style='display: inline-block'><a style='text-decoration: none' href='$direktorija$file' target='_blank'><h4 style='color: black'>$file</h4></a></div>
        </div>
        <div class='mygtukas1'>
          <a class='button' style='margin-left: 5px; text-decoration: none;' href='$direktorija$file' target='_blank'>Peržiūrėti</a>
          <a class='button' style='margin-left: 5px; text-decoration: none;' href='$direktorija$file' download >Atsisiųsti</a>
        </div>
      </div>

      <br>";
    }
  }
}

else{
  mkdir($direktorija);
}

?>
<style>
.ilginimas{
  width: 88%;
}
@media only screen and (max-width: 600px) {
  .ilginimas-mygt{
    width: 99%;
    margin-top: -10px;
  }
  .ilginimas{
    width: 100%;
  }
  .topas{
    margin-top: 25px;
  }
}

</style>
<br>


<div class='card94' style='text-align: center; margin-right: 1rem; padding-top: 2rem; padding-bottom: 2rem; margin-bottom: 2rem'>

  <label style="margin-bottom: 10px; display: inline-block; cursor: pointer" onclick="perziurejimofunkcija()" class='prapletimas button'>Peržiūrėti tekstinį failą</label>
  <label style="margin-bottom: 10px; display: inline-block; cursor: pointer" onclick="redagavimofunkcija()" class='prapletimas button'>Redaguoti tekstinį failą</label>

</div>




<div id='perziurejimas' style='display: none; margin-bottom: 2rem'>

  <form method="post" action="">

    <div class='ilginimas' style='display: inline-block'><select class='ivedimas' style="height: 48px; padding: 0px 16px 0px 16px !important; width: 99%" type="text" name="pavadinimas">
          <option selected="selected">Pasirinkti</option>
          <?php
          foreach($tekstiniai as $item){
              echo "<option>$item</option>";
          }
          ?>
      </select>

    </div>

    <div class='ilginimas-mygt' style='display: inline-block; text-align: center'><input class='button' type="submit" value='Peržiūrėti'/></div>

  </form>

</div>


<?php


if(isset($_POST['pavadinimas']) && $_POST['pavadinimas'] != 'Pasirinkti')
{

  $selected = $_POST['pavadinimas'];

?>

<div class='card94' style='padding-bottom: 3rem; margin-bottom: 2rem'> <h3 style='text-align: center'>Tekstinio failo "<? echo $selected ?>" peržiūra </h3> <br> <?php echo file_get_contents($direktorija.$selected.'.txt'); ?></div>
<?php

}

?>


<br>
<br>

<div id='redagavimas' style='display: none; margin-bottom: 10rem'>
  <h3 style='text-align: center'>Tekstinio failo redagavimas </h3> <br>
  <form method="post" action="redagavimas.php" style='margin-bottom: 100px'>

    <select class='ivedimas ilginimas' style="height: 48px; padding: 0px 16px 0px 16px !important; width: 99%" type="text" name="failo_pavadinimas">
          <option selected="selected">Pasirinkti</option>
          <?php
          foreach($tekstiniai as $item){
              echo "<option>$item</option>";
          }
          ?>
      </select>


   <div class='ilginimas-mygt ilginimas' style='display: inline-block'><textarea style='margin-bottom: -45px; height: 100px; margin-top: 20px; border-width: 2px; border-radius: 10px; border-color: #658feb; width: 99%; padding: 10px' name="edit_text"></textarea></div>
   <div style='display: inline-block; margin-top: 30px; text-align: center' class='ilginimas-mygt'><input class='button topas' type="submit" value="Išsaugoti" name="redaguoti_faila"></div>

  </form>
</div>

<script>
function perziurejimofunkcija() {
  var x = document.getElementById("perziurejimas");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
function redagavimofunkcija() {
  var x = document.getElementById("redagavimas");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>
