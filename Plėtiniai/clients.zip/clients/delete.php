<?php

include "../../config.php";
include '../../loggedin.php';
$id = $_GET['id'];

$del = mysqli_query($con,"delete from clients where id = '$id'");

if($del)
{
    mysqli_close($con);
    header("Location: clients");
    exit;
}
else
{
    echo "Error deleting record";
}
?>
