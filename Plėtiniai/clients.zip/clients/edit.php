<?php
session_start();

include '../../sidemenu.php';

$id = $_GET['id'];

$qry = mysqli_query($con,"SELECT *from clients WHERE id='" . $id . "'");
$data=mysqli_fetch_array($qry);

if ($role != 1) {

  if ($role != 2) {

    if ($role != 3) {

      echo "<script> location.href='../clients/clients'; </script>";
        exit;

    }

  }

}


if(isset($_POST['update']))
{
  $username = $_POST['username'];
  $surname = $_POST['surname'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];

  if (empty($_POST['username'])){

    $message1 = "Neįvestas vartotojo vardas!";

  }

  if (!empty($_POST['username'])){

    mysqli_query($con,"UPDATE clients set username='$username' where id='$id'");

  }
  if (!empty($_POST['surname'])){

    mysqli_query($con,"UPDATE clients set surname='$surname' where id='$id'");

  }
  if (!empty($_POST['phone'])){

    mysqli_query($con,"UPDATE clients set phone='$phone' where id='$id'");

  }
  if (!empty($_POST['email'])){

    mysqli_query($con,"UPDATE clients set email='$email' where id='$id'");

  }

  if (!empty($_POST['username'])){

    echo "<script> location.href='../clients/clients'; </script>";
          exit;


  }



}
?>
<head>
    <meta charset="UTF-8">
    <style>
    .sidebar{
      min-height: 125vh !important;
    }
    .ivedimas{
      width: 95%;
    }
    @media only screen and (max-width: 800px){

      .ivedimas{
        margin-bottom: 0px;
      }
    }
    </style>
</head>
<div class = "wrapper">
  <form method="POST" action="" enctype="multipart/form-data" class="card94" style='text-align: center'>
    <h2 style="color: black;">Vartotojo "<?php echo $data['username'] ?>" redagavimas</h2>
    <br>
    <div class="row">

      <div class="column50" style="width: 100%; text-align: left" >
        <h4 class='punktas'>Vardas* </h4>
        <input class="ivedimas" type="text" autocomplete="off" name="username" value="<?php echo $data['username'] ?>" >
        <br>
        <h4 class='punktas'>Pavardė </h4>
        <input class="ivedimas" type="text" autocomplete="off" name="surname" value="<?php echo $data['surname'] ?>" >
        <br>
        <h4 class='punktas'>Telefonas </h4>
        <input class="ivedimas" type="text" autocomplete="off" name="phone" value="<?php echo $data['phone'] ?>" >
        <br>
        <h4 class='punktas'>El. Paštas </h4>
        <input style="margin-bottom: 2rem" autocomplete="off" class="ivedimas" type="text" name="email" value="<?php echo $data['email'] ?>" >

      </div>

    </div>

        <button style='margin-bottom: 20px; margin-top: 20px' class="button" onclick="location.href='../clients/clients'" type='button'>Atšaukti</button>
        <button class="button" type="submit" name="update">Atnaujinti</button>

        <br>
        <br>
      </div>

    </div>
    <br>
    <br>

  </form>
</div>
