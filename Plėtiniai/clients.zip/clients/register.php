<?php
session_start();
include '../../sidemenu.php';
$records = mysqli_query($con,"select * from clients");

if ($role != 1) {

  if ($role != 2) {

    if ($role != 3) {

      echo "<script> location.href='../clients/clients'; </script>";
        exit;

    }

  }

}

if(isset($_POST['update']))
{
  $id =  $_REQUEST['id'];
        $username =  $_REQUEST['username'];
        $surname = $_REQUEST['surname'];
        $email =  $_REQUEST['email'];
        $phone = $_REQUEST['phone'];

        if (empty($_POST['username'])){

          $message1 = "Neįvestas vartotojo vardas!";

        }

        else{

          $sql = "INSERT INTO clients  VALUES ('','$username','$surname','$email','$phone')";

          if(mysqli_query($con, $sql)){
          }
          else{
          }

          mysqli_close($con);

          echo "<script> location.href='../clients/clients'; </script>";
                  exit;

        }

}

?>

<head>
    <meta charset="UTF-8">
    <style>
    .sidebar{
      min-height: 125vh !important;
    }
    .ivedimas{
      width: 95%;
    }
    @media only screen and (max-width: 800px){

      .ivedimas{
        margin-bottom: 0px;
      }
    }
    </style>
</head>
<div class = "wrapper">
  <form method="POST" action="" class="card94" style='text-align: center'>
    <h2 style="color: black;">Naujo kliento registracija</h2>
    <div class="row">


      <div class="column50" style="width: 100%; text-align: left" >
        <h4 class='punktas'>Vardas* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="username" id="username" placeholder='<?php echo $message1; ?>'>
        <br>
        <h4 class='punktas'>Pavardė </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="surname" id="surname" >
        <br>
        <h4 class='punktas'>Telefonas </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="phone" id="phone" >
        <br>
        <h4 class='punktas'>El. Paštas </h4>
        <input style="margin-bottom: 2rem" autocomplete="off" class="ivedimas" type="email" name="email" id="email" >

      </div>

    </div>

        <button style='margin-bottom: 20px; margin-top: 20px' class="button" onclick="location.href='../clients/clients'" type='button'>Atšaukti</button>
        <button class="button" type="submit" name="update">Registruoti</button>

        <br>
        <br>
      </div>

    </div>
    <br>
    <br>

  </form>
</div>
