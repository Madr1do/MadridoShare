<?php
include '../../sidemenu.php';
$stmt = $con->prepare('SELECT username FROM clients WHERE id = ?');
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($dabartinis);
$stmt->fetch();
$stmt->close();

?>

  <?php
  if ($role == 1 || $role == 2 || $role == 3) {
    ?>
  <div class='card94' style='text-align: center; margin-right: 1rem; padding-top: 2rem; padding-bottom: 2rem; margin-bottom: 2rem'>
      <a class='button' style="text-decoration: none" href="../clients/register">Naujas klientas</a>
  </div>
<?php } ?>

<?php

$records = mysqli_query($con,"select * from clients");

?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
}

th {
  text-align: left;
  padding: 8px;
  font-size: 18px;
  padding-bottom: 20px;
  padding-top: 20px;
  border: 2px solid #658feb;
  background-color: #deebff;
}

td {
  text-align: left;
  padding: 8px;
  font-size: 13px;
  border: 2px solid #658feb;
  padding-bottom: 20px;
  padding-top: 20px;
}

.delete{
  padding-left: 29px;
  padding-right: 29px;
}
.delete:hover{
  padding-left: 29px;
  padding-right: 29px;
}
.lygiuote{
  padding-left: 8px;
}
@media only screen and (max-width: 800px) {
  .lygiuote{
    padding-left: 70px; padding-right: 70px;
  }
}
</style>
</head>
<body>

<div class='card94' style='text-align: center; margin-right: 1rem; padding-top: 2rem; padding-bottom: 2rem; margin-bottom: 2rem; overflow-x:auto;'>
  <table>
    <tr>
      <th>Vardas</th>
      <th>Pavardė</th>
      <th>El. paštas</th>
      <th>Telefonas</th>
      <th class='lygiuote'>Veiksmai</th>
    </tr>

    <?php

    while($data = mysqli_fetch_array($records))

    { ?>
    <tr>
      <td><?php echo $data['username']; ?></td>
      <td><?php echo $data['surname']; ?></td>
      <td><?php echo $data['email']; ?></td>
      <td><?php echo $data['phone']; ?></td>
      <?php
      if ($role == 1 || $role == 2) {
        ?>
        <td style='border: none; text-align: center'>
          <a class='button' style="font-size: 14px; text-decoration: none" href="edit.php?id=<?php echo $data['id']; ?>">Redaguoti</a>
          <a class='delete' style="font-size: 14px; text-decoration: none" href="delete.php?id=<?php echo $data['id']; ?>">Trinti</i></a>
        </td>
        <?php
      }
      if ($role == 3) {
        ?>
        <td style='border: none; text-align: center'>
          <a class='button' style="font-size: 14px; text-decoration: none" href="edit.php?id=<?php echo $data['id']; ?>">Redaguoti</a>
        </td>
        <?php
      }
      if ($role == 4){
        ?>
        <td style='border: none; text-align: center'>
          <a class='button' style="padding-left: 0px; border: none; color: #e74c3c; cursor: auto; background-color: transparent !important; text-decoration: none">Veiksmai negalimi</a>
        </td>
        <?php
      }
    ?>
    </tr>

  <?php }
  ?>
  </table>
</div>

</body>
</html>
