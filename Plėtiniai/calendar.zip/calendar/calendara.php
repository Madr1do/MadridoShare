<style>
/* (A) FONT */
/* (B) PERIOD SELECTOR */
#calPeriod input, #calPeriod select {
  font-size: 16px;
  border: 0;
  outline: none;
  border: 2px solid #3d3228;
}
#calmonth { width: 120px; }
#calyear { width: 80px; text-align: left; border: 1px solid #658feb;}

@media only screen and (max-width: 400px) {

  #calPeriod{
    width: 84% !important;
  }

  #calform{
    width: 80% !important;
  }

}
@media only screen and (min-width: 400px) and (max-width: 800px) {

  #calPeriod{
    width: 92% !important;
  }

  #calform{
    width: 80% !important;
  }

}

/* (C) CALENDAR */
#calwrap {
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 5%;
}
.kalendorius {
  box-sizing: border-box;
  width: 14.28%;
  padding: 5px;
}
.kalendorius.head {
  background: rgba(255,255,255,.2);
  font-weight: bold;
  text-align: center;
}
.kalendorius.tuscias, .kalendorius.day {
  height: 100px;
    overflow-y: auto;
    border: 1px solid #658feb;
    background-color: #658feb30;
    margin-bottom: 10px;
    margin-top: 10px;
    cursor: pointer;
}
.kalendorius.tuscias { background: white; }
.kalendorius.today { background: #658feb; color: white; }
.diena { color: auto; }
.ivykis {
  height: 20px;
  color: black;
  font-style: italic;
  font-size: 10px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.calninja { display: none; }

/* (D) EVENT FORM */
#calblock {
  position: fixed;
  top: 0; left: 0;
  z-index: 998;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  transition: opacity 0.2s;
  opacity: 0;
  visibility: hidden;
}
#calblock.show {
  opacity: 1;
  visibility: visible;
}
#calform {
  z-index: 999;
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  background-clip: border-box;
  border: 1px solid #e3e6f0;
  display: inline-block;
  width: 30%;
  border-radius: 10px;
  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
  padding: 1rem 1rem 1rem 2rem;
  border-left: 5px solid #658feb;
  transition: 300ms;
}
#calform label {
  color: black;
}
#calform input, #calform textarea {
  width: 100%;
  font-size: 16px;
  border-radius: 10px;
  border: none;
  color: black;
  padding: 16px;
  background: white;
  height: auto;
  border: 2px solid #658feb;
  margin-top: 1rem;
  margin-bottom: 1rem;
  cursor: pointer;
}
#calformsave {
    color: #f1eded !important;
    background-color: #658feb !important;
    border: 2px solid #658feb !important;
    border-radius: 5px !important;
    font-size: 16px !important;
    padding: 10px !important;
    text-align: center !important;
    font-family: 'Poppins' !important;
    transition: 300ms !important;
    cursor: pointer !important;
}
#calformsave:hover {
  color: #658feb !important;
  background-color: white !important;
  border: 2px solid #658feb !important;
  border-radius: 5px !important;
  font-size: 16px !important;
  padding: 10px !important;
  text-align: center !important;
  font-family: 'Poppins' !important;
  transition: 300ms !important;
  cursor: pointer !important;
}
#calformcx {
  color: #658feb !important;
  background-color: white !important;
  border: 2px solid #658feb !important;
  border-radius: 5px !important;
  font-size: 16px !important;
  padding: 10px !important;
  text-align: center !important;
  font-family: 'Poppins' !important;
  transition: 300ms !important;
  cursor: pointer !important;
}

#calformcx:hover {
  color: #f1eded !important;
  background-color: #658feb !important;
  border: 2px solid #658feb !important;
  border-radius: 5px !important;
  font-size: 16px !important;
  padding: 10px !important;
  text-align: center !important;
  font-family: 'Poppins' !important;
  transition: 300ms !important;
  cursor: pointer !important;
}
#calformdel{
  color: #f1eded !important;
  background-color: #e74c3c !important;
  border: 2px solid #e74c3c !important;
  border-radius: 5px !important;
  font-size: 16px !important;
  padding: 10px !important;
  text-align: center !important;
  font-family: 'Poppins' !important;
  transition: 300ms !important;
  cursor: pointer !important;
  padding-left: 12px !important;
  padding-right: 12px !important;
}
#calformdel:hover {
  color: #e74c3c !important;
  background-color: white !important;
  border: 2px solid #e74c3c !important;
  border-radius: 5px !important;
  font-size: 16px !important;
  padding: 10px !important;
  text-align: center !important;
  font-family: 'Poppins' !important;
  transition: 300ms !important;
  cursor: pointer !important;
  padding-left: 12px !important;
  padding-right: 12px !important;
}
</style>
