<?php
// (A) INVALID AJAX REQUEST
if (!isset($_POST['req'])) { die("INVALID REQUEST"); }
require "cal-core.php";
switch ($_POST['req']) {
  // (B) DRAW CALENDAR FOR MONTH
  case "draw":
    // (B1) DATE RANGE CALCULATIONS
    // NUMBER OF dayS IN MONTH
    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $_POST['month'], $_POST['year']);
    // FIRST & LAST day OF MONTH
    $dateFirst = "{$_POST['year']}-{$_POST['month']}-01";
    $dateLast = "{$_POST['year']}-{$_POST['month']}-{$daysInMonth}";
    // day OF WEEK - NOTE 0 IS SUNday
    $dayFirst = (new DateTime($dateFirst))->format("w");
    $dayLast = (new DateTime($dateLast))->format("w");

    // (B2) day NAMES
    $sunFirst = false; // CHANGE THIS IF YOU WANT MON FIRST
    $days = ["I", "II", "III", "IV", "V", "VI"];
    if ($sunFirst) { array_unshift($days, "VII"); }
    else { $days[] = "VII"; }
    foreach ($days as $d) { echo "<div class='kalendorius head'>$d</div>"; }
    unset($days);

    // (B3) PAD EMPTY SQUARES BEFORE FIRST day OF MONTH
    if ($sunFirst) { $pad = $dayFirst; }
    else { $pad = $dayFirst==0 ? 6 : $dayFirst-1 ; }
    for ($i=0; $i<$pad; $i++) { echo "<div class='kalendorius tuscias'></div>"; }

    // (B4) DRAW dayS IN MONTH
    $events = $CAL->get($_POST['month'], $_POST['year']);
    $nowMonth = date("n");
    $nowYear = date("Y");
    $nowDay = ($nowMonth==$_POST['month'] && $nowYear==$_POST['year']) ? date("j") : 0 ;
    for ($day=1; $day<=$daysInMonth; $day++) { ?>
    <div class="kalendorius day<?=$day==$nowDay?" today":""?>" data-day="<?=$day?>">
      <div class="diena"><?=$day?></div>
        <?php if (isset($events['d'][$day])) { foreach ($events['d'][$day] as $eid) { ?>
        <div class="ivykis" data-eid="<?=$eid?>"
             style="background:<?=$events['e'][$eid]['evt_color']?>">
          <?=$events['e'][$eid]['evt_text']?>
        </div>
        <?php if ($day == $events['e'][$eid]['first']) {
          echo "<div id='evt$eid' class='calninja'>".json_encode($events['e'][$eid])."</div>";
        }}} ?>
      </div>
    <?php }

    // (B5) PAD EMPTY SQUARES AFTER LAST day OF MONTH
    if ($sunFirst) { $pad = $dayLast==0 ? 6 : 6-$dayLast ; }
    else { $pad = $dayLast==0 ? 0 : 7-$dayLast ; }
    for ($i=0; $i<$pad; $i++) { echo "<div class='kalendorius tuscias'></div>"; }
    break;

  // (C) SAVE EVENT
  case "save":
    echo $CAL->save(
      $_POST['start'], $_POST['end'], $_POST['txt'], $_POST['color'],
      isset($_POST['eid']) ? $_POST['eid'] : null
    ) ? "OK" : $CAL->error ;
    break;

  // (D) DELETE EVENT
  case "del":
    echo $CAL->del($_POST['eid']) ? "OK" : $CAL->error ;
    break;
}
