<?php
include '../../sidemenu.php';
 ?>
<link rel="stylesheet" href="calendara.php">
<script src="calendar.js"></script>

<!-- (B) PERIOD SELECTOR -->
<div id="calPeriod" style='
background-color: #fff;
margin-bottom: 1rem;
border-radius: 10px;
box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
padding: 1rem 1rem 1rem 2rem;
width: 95%;
border-left: 5px solid #658feb;
cursor: pointer;'><?php
  // (B1) MONTH SELECTOR
  // NOTE: DEFAULT TO CURRENT SERVER MONTH YEAR
  $months = [
    1 => "Sausis", 2 => "Vasaris", 3 => "Kovas", 4 => "Balandis",
    5 => "Gegužė", 6 => "Birželis", 7 => "Liepa", 8 => "Rugpjūtis",
    9 => "Rugsėjis", 10 => "Spalis", 11 => "Lapkritis", 12 => "Gruodis"
  ];
  $monthNow = date("m");
  echo "<select id='calmonth' style='border-radius: 10px; border-color: #658feb; padding: 0.5rem 0.5rem 0.5rem 0.5rem; margin-right: 1rem; height: 40px'>";
  foreach ($months as $m=>$mth) {
    printf("<option value='%s'%s>%s</option>",
      $m, $m==$monthNow?" selected":"", $mth
    );
  }
  echo "</select>";

  // (B2) YEAR SELECTOR
  echo "<input type='number' id='calyear' style='border-radius: 10px; border-color: #658feb; padding: 0.5rem 0.5rem 0.5rem 0.5rem; height: 40px' value='".date("Y")."'/>";
?></div>

<style>
.sidebar{
      min-height: 127vh !important;
}
</style>

<!-- (C) CALENDAR WRAPPER -->
<div id="calwrap" style='
background-color: #fff;
border: 1px solid #e3e6f0;
border-radius: 10px;
box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
padding: 1rem 1rem 1rem 2rem;
border-left: 5px solid #658feb;
'></div>

<!-- (D) EVENT FORM -->
<div id="calblock"><form id="calform">
  <input type="hidden" id="evtid"/>
  <label for="start">Pradžia</label>
  <input type="date" id="evtstart" required/>
  <label for="end">Pabaiga</label>
  <input type="date" id="evtend" required/>
  <label for="txt">Termino pavadinimas</label>
  <textarea id="evttxt" required></textarea>
  <label style='display: none' for="color">Spalva</label>
  <input style='display: none' type="color" id="evtcolor" value="#e4edff" required/>
  <input type="submit" style='margin-bottom: -5px' id="calformsave" value="Išsaugoti"/>
  <input type="button" id="calformdel" value="Ištrinti"/>
  <input type="button" id="calformcx" value="Atšaukti"/>
</form></div>
