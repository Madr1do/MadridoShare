<?php

include '../../sidemenu.php';

$id = $_GET['id'];
$drole = $role;
$qry = mysqli_query($con,"SELECT *from accounts WHERE id='" . $id . "'");
$data=mysqli_fetch_array($qry);

if ($role != 1) {

  if ($role != 2) {

    echo "<script> location.href='../accounts/accounts'; </script>";
            exit;

  }

}

$vartotojas = $data['id'];

$paveiksliukas = $data['image'];

$linkas = ('../../images/'.$vartotojas.'/'.$paveiksliukas);

if(isset($_POST['update']))
{
  $username = $_POST['username'];
  $email = $_POST['email'];
  $role = $_POST['role'];
  $password = $_POST['password'];
  $verify_password = $_POST['verify-password'];
  $surname = $_POST['surname'];
  $phone = $_POST['phone'];
  $image = $_FILES["files"]["name"];

  if (!empty($_POST['username'])){

    mysqli_query($con,"UPDATE accounts set username='$username' where id='$id'");

  }

  if (empty($_POST['username'])){

    $nera_vardo = "Neįvestas vardas!";

  }

  if (!empty($_POST['surname'])){

    mysqli_query($con,"UPDATE accounts set surname='$surname' where id='$id'");

  }

  if (empty($_POST['surname'])){

    $nera_pavardes = "Neįvesta pavardė!";

  }

  if (!empty($_POST['email'])){

    mysqli_query($con,"UPDATE accounts set email='$email' where id='$id'");

  }

  if (empty($_POST['email'])){

    $nera_pasto = "Neįvestas el. paštas!";

  }

  if (!empty($_POST['phone'])){

    mysqli_query($con,"UPDATE accounts set phone='$phone' where id='$id'");

  }

  if (empty($_POST['phone'])){

    $nera_telefono = "Neįvestas telefonas!";

  }

  if (!empty($_POST['password'])){

    if ($_POST['verify-password'] == $_POST['password']){

      $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
      mysqli_query($con,"UPDATE accounts set password='$password' where id='$id'");

    }

    if (empty($_POST['verify-password'])){

      $nera_slaptazodzio_pakartojimo = "Neįvestas slaptažodžio pakartojimas!";

    }

    if ($_POST['verify-password'] != $_POST['password']){

      if (!empty($_POST['verify-password'])){

        $nesutampa = "Slaptažodžiai nesutampa!";

      }

    }

  }

  if (!empty($_POST['role'])){

    if($_POST['role'] == 'Administratorius')
    {
       mysqli_query($con,"UPDATE accounts set role='1' where id='$id'");
    }
    if($_POST['role'] == 'Vykdytojas')
    {
       mysqli_query($con,"UPDATE accounts set role='2' where id='$id'");
    }
    if($_POST['role'] == 'Darbuotojas')
    {
       mysqli_query($con,"UPDATE accounts set role='3' where id='$id'");
    }
    if($_POST['role'] == 'Nepriskirta')
    {
       mysqli_query($con,"UPDATE accounts set role='4' where id='$id'");
    }


  }

  if ($_FILES['files']['size'] != 0) {

          if (!file_exists('../../images/'.$vartotojas)) {
              mkdir('../../images/'.$vartotojas, 0777, true);
          }



            mysqli_query($con,"UPDATE accounts set image='$image' where id='$vartotojas'");

            $target_dir = '../../images/'.$vartotojas.'/';
            $target_file = $target_dir . basename($_FILES["files"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            move_uploaded_file($_FILES["files"]["tmp_name"], $target_file);


  }

  if  (!empty($_POST['username']) && !empty($_POST['surname']) && !empty($_POST['email']) && !empty($_POST['phone'])){

    if (!empty($_POST['password'])){

      if (!empty($_POST['verify-password']) && $_POST['verify-password'] == $_POST['password']){

        echo "<script> location.href='../accounts/accounts'; </script>";
                exit;

      }

    }

    if (empty($_POST['verify-password']) && empty($_POST['password'])){

        echo "<script> location.href='../accounts/accounts'; </script>";
                exit;

    }

  }

}
?>
<head>
    <meta charset="UTF-8">
    <style>
    .sidebar{
      min-height: 135vh !important;
    }
    .ivedimas{
      width: 100%;
    }
    @media only screen and (max-width: 400px){
      .button {
          width: 90%;
      }
      h2{
        text-align: center;
      }
    }
    @media only screen and (max-width: 800px){

      h2{
        text-align: center;
      }

      .ivedimas{
        margin-bottom: 0px;
      }
    }
    </style>
</head>
<?php
if ($drole != 1){
  if ($data['role'] == 1){
    ?><a class='button' style="padding-left: 0px; border: none; color: #e74c3c; cursor: auto; background-color: transparent !important; text-decoration: none">Redagavimas negalimas</a><?php
  }
  else{
    ?>
    <div class = "wrapper">
      <form method="POST" action="" enctype="multipart/form-data" class="card94" style='text-align: center'>

      <div class="row">

        <div class="column50" style='text-align: left'>

          <div class="row">

            <h2 style="color: black;">Vartotojo „<?php echo $data['username']?>“ paskyros redagavimas</h2>

            <div class="column50" style='text-align: left'>

              <?php
              if (@getimagesize($linkas)) {
                echo "<img class='paveiksliukas' src='$linkas' >";
              }
              else {
                echo  "<img class='paveiksliukas' src='../../images/doge.jpg' >";
              }
              ?>

            </div>

            <div class="column50" style='margin-top: 2rem;'>

              <label style="display: inline-block; cursor: pointer" class='button' for="files">Pakeisti nuotrauką</label>
              <br>
              <input style="display: inline-block; width: 20px; visibility:hidden;" type="file" id="files" name="files" />
              <br>

            </div>

          </div>

        </div>

        <div class="column50 klaida" style='text-align: left; margin-top: 1rem'>

          <p><?php echo $nera_vardo ?></p>
          <p><?php echo $nera_pavardes ?></p>
          <p><?php echo $nera_slaptazodzio ?></p>
          <p><?php echo $nera_slaptazodzio_pakartojimo ?></p>
          <p><?php echo $nesutampa ?></p>
          <p><?php echo $nera_pasto ?></p>
          <p><?php echo $nera_telefono ?></p>
          <p><?php echo $pastas_yra ?></p>

        </div>

      </div>

        <div class="row">

          <div class="column50" style="width: 92%; text-align: left">
            <h4 class='punktas'>Vardas </h4>
            <input class="ivedimas" autocomplete="off" type="text" name="username" value="<?php echo $data['username'] ?>" >
            <br>
            <h4 class='punktas'>Pavardė </h4>
            <input class="ivedimas" autocomplete="off" type="text" name="surname" value="<?php echo $data['surname'] ?>" >
            <br>
            <h4 class='punktas'>Slaptažodis </h4>
            <input class="ivedimas" autocomplete="off" type="text" name="password" placeholder='**********'>
            <br>
            <h4 class='punktas'>Pakartokite slaptažodį </h4>
            <input class="ivedimas" autocomplete="off" type="text" name="verify-password" placeholder='**********'>
            <br>
            <h4 class='punktas'>El. Paštas </h4>
            <input class="ivedimas" autocomplete="off" type="email" name="email" value="<?php echo $data['email'] ?>" >
            <br>
            <h4 class='punktas'>Telefonas </h4>
            <input class="ivedimas" autocomplete="off" type="text" name="phone" value="<?php echo $data['phone'] ?>" >
            <br>
            <h4 class='punktas'>Pareigos </h4>
            <?php
            if ($data['role'] == "2"){
              ?>
              <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
                <option value="Vykdytojas">Vykdytojas</option>
                <option value="Darbuotojas">Darbuotojas</option>
                <option value="Nepriskirta">Nepriskirta</option>
              </select>
              <?php
            }
            if ($data['role'] == "3"){
              ?>
              <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
                <option value="Darbuotojas">Darbuotojas</option>
                <option value="Vykdytojas">Vykdytojas</option>
                <option value="Nepriskirta">Nepriskirta</option>
              </select>
              <?php
            }
            if ($data['role'] == "4"){
              ?>
              <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
                <option value="Nepriskirta">Nepriskirta</option>
                <option value="Vykdytojas">Vykdytojas</option>
                <option value="Darbuotojas">Darbuotojas</option>
              </select>
              <?php
            }
            ?>

          </div>

        </div>

            <button class="button" onclick="location.href='../accounts/accounts'" type='button'>Atšaukti</button>
            <button class="button" type="submit" name="update">Atnaujinti</button>
            <br>
            <br>
          </div>

        </div>
        <br>
        <br>

      </form>
    </div>
    <?php
  }
}
else{
 ?>
<div class = "wrapper">
  <form method="POST" action="" enctype="multipart/form-data" class="card94" style='text-align: center'>

  <div class="row">

    <div class="column50" style='text-align: left'>

      <div class="row">

        <h2 style="color: black;">Vartotojo „<?php echo $data['username']?>“ paskyros redagavimas</h2>

        <div class="column50">

          <?php
          if (@getimagesize($linkas)) {
            echo "<img class='paveiksliukas' src='$linkas' >";
          }
          else {
            echo  "<img class='paveiksliukas' src='../../images/doge.jpg' >";
          }
          ?>

        </div>

        <div class="column50" style='margin-top: 2rem'>

          <label style="display: inline-block; cursor: pointer" class='button' for="files">Pakeisti nuotrauką</label>
          <br>
          <input style="display: inline-block; width: 20px; visibility:hidden;" type="file" id="files" name="files" />
          <br>

        </div>

      </div>

    </div>

    <div class="column50 klaida" style='text-align: left; margin-top: 1rem;'>

      <p><?php echo $nera_vardo ?></p>
      <p><?php echo $nera_pavardes ?></p>
      <p><?php echo $nera_slaptazodzio ?></p>
      <p><?php echo $nera_slaptazodzio_pakartojimo ?></p>
      <p><?php echo $nesutampa ?></p>
      <p><?php echo $nera_pasto ?></p>
      <p><?php echo $nera_telefono ?></p>
      <p><?php echo $pastas_yra ?></p>

    </div>

  </div>

    <div class="row">

      <div class="column50" style="width: 92%; text-align: left">
        <h4 class='punktas'>Vardas* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="username" value="<?php echo $data['username'] ?>" >
        <br>
        <h4 class='punktas'>Pavardė* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="surname" value="<?php echo $data['surname'] ?>" >
        <br>
        <h4 class='punktas'>Slaptažodis </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="password" placeholder='**********'>
        <br>
        <h4 class='punktas'>Pakartokite slaptažodį </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="verify-password" placeholder='**********'>
        <br>
        <h4 class='punktas'>El. Paštas* </h4>
        <input class="ivedimas" autocomplete="off" type="email" name="email" value="<?php echo $data['email'] ?>" >
        <br>
        <h4 class='punktas'>Telefonas* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="phone" value="<?php echo $data['phone'] ?>" >
        <br>
        <h4 class='punktas'>Pareigos* </h4>
        <?php
        if ($data['role'] == "1"){
          ?>
          <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
            <option value="Administratorius">Administratorius</option>
            <option value="Vykdytojas">Vykdytojas</option>
            <option value="Darbuotojas">Darbuotojas</option>
            <option value="Nepriskirta">Nepriskirta</option>
          </select>
          <?php
        }
        if ($data['role'] == "2"){
          ?>
          <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
            <option value="Vykdytojas">Vykdytojas</option>
            <option value="Administratorius">Administratorius</option>
            <option value="Darbuotojas">Darbuotojas</option>
            <option value="Nepriskirta">Nepriskirta</option>
          </select>
          <?php
        }
        if ($data['role'] == "3"){
          ?>
          <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
            <option value="Darbuotojas">Darbuotojas</option>
            <option value="Administratorius">Administratorius</option>
            <option value="Vykdytojas">Vykdytojas</option>
            <option value="Nepriskirta">Nepriskirta</option>
          </select>
          <?php
        }
        if ($data['role'] == "4"){
          ?>
          <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
            <option value="Nepriskirta">Nepriskirta</option>
            <option value="Administratorius">Administratorius</option>
            <option value="Vykdytojas">Vykdytojas</option>
            <option value="Darbuotojas">Darbuotojas</option>
          </select>
          <?php
        }
        ?>

      </div>

    </div>

        <button style='margin-bottom: 20px; margin-top: 50px' class="button" onclick="location.href='../accounts/accounts'" type='button'>Atšaukti</button>
        <button class="button" type="submit" name="update">Atnaujinti</button>
        <br>
        <br>
      </div>

    </div>
    <br>
    <br>

  </form>
</div>
<?php } ?>
