<?php
include '../../sidemenu.php';
$stmt = $con->prepare('SELECT username FROM accounts WHERE id = ?');
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($dabartinis);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <?php
  if ($role == 1 || $role == 2) {
    ?>
  <div class='card94' style='text-align: center; margin-right: 1rem; padding-top: 2rem; padding-bottom: 2rem; margin-bottom: 2rem'>
      <a class='button' style="text-decoration: none" href="../accounts/register">Naujas vartotojas</a>
  </div>
<?php } ?>
<?php

$records = mysqli_query($con,"select * from accounts"); // fetch data from database


while($data = mysqli_fetch_array($records))
{

  $vartotojas = $data['id'];

  $image = $data['image'];

  $linkas = ('../../images/'.$vartotojas.'/'.$image);

  if ($vartotojas == $_SESSION['id']) {

    echo '';

  }

  else{

  ?>
  <div class='card25' style='cursor: default; margin-right: 1rem;'>

      <?php
      if (@getimagesize($linkas)) {
        echo "<img class='mazaspaveiksliukas' src='$linkas' >";
      } else {
        echo  "<img class='mazaspaveiksliukas' src='../../images/doge.jpg' >";

      }?>

      <br>
      <br>
      <p style="line-height: 1px; font-weight: bold; color: #658feb">VARDAS: </p><p style='font-size: 14px'> <?php echo $data['username']; ?></p>
      <p style='height: 1px'></p>
      <p style="line-height: 1px; font-weight: bold; color: #658feb">PAVARDĖ: </p><p style='font-size: 14px'> <?php echo $data['surname']; ?></p>
      <p style='height: 1px'></p>
      <p style="line-height: 1px; font-weight: bold; color: #658feb">PAREIGOS: </p><p style='font-size: 14px'><?php
      if ($data['role'] == 1) {
        echo 'Administratorius';
      }
      elseif ($data['role'] == 2) {
        echo 'Vykdytojas';
      }
      elseif ($data['role'] == 3) {
        echo 'Darbuotojas';
      }
      else{
        echo 'Nepriskirta';
      }
      ?></p>
      <p style='height: 1px'></p>
      <p style="line-height: 1px; font-weight: bold; color: #658feb">TELEFONAS: </p><p style='font-size: 14px'> <?php echo $data['phone']; ?></p>
      <p style='height: 1px'></p>
      <p style="line-height: 1px; font-weight: bold; color: #658feb">EL. PAŠTAS: </p><p style='font-size: 14px'> <?php echo $data['email']; ?></p>
      <br>
      <span>
        <?php
        if ($role == 1 ) {
          ?><a class='button' style="text-decoration: none" href="edit.php?id=<?php echo $data['id']; ?>">Redaguoti</a><?php
        }
        if ($role == 2 ) {
          if ($data['role'] == 1 ) {
          ?><a class='button' style="padding-left: 0px; border: none; color: #e74c3c; cursor: auto; background-color: transparent !important; text-decoration: none">Redagavimas negalimas</a><?php
          }
          else{
          ?><a class='button' style="text-decoration: none" href="edit.php?id=<?php echo $data['id']; ?>">Redaguoti</a><?php
          }
        }

        if ($role == 1 ) {
          ?><a class='delete' style="margin-left: 5px; text-decoration: none" href="delete.php?id=<?php echo $data['id']; ?>">Ištrinti</a><?php
        }
         ?>
      </span>
      <br>
      <br>
    </div>
  <?php
  }
}
?>
</table>

</body>
</html>
