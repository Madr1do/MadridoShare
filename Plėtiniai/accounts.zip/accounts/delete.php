<?php

include "../../config.php";
include '../../loggedin.php';
$id = $_GET['id'];

$del = mysqli_query($con,"delete from accounts where id = '$id'");

$linkas = ('../../images/'.$id);
$dokumentai = ('../../files/'.$id);


if($del)
{
    mysqli_close($con);

    if (substr($linkas, strlen($linkas) - 1, 1) != '/') {
        $linkas .= '/';
    }
    $files = glob($linkas . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            self::deleteDir($file);
        } else {
            unlink($file);
        }
    }
    rmdir($linkas);

    if (substr($dokumentai, strlen($dokumentai) - 1, 1) != '/') {
        $dokumentai .= '/';
    }
    $files = glob($dokumentai . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            self::deleteDir($file);
        } else {
            unlink($file);
        }
    }
    rmdir($dokumentai);


    header("Location: accounts");
    exit;
}
else
{
    echo "Klaida";
}
?>
