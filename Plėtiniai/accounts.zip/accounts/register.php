<?php
session_start();
include '../../sidemenu.php';
$records = mysqli_query($con,"select * from accounts");

if ($role != 1) {

  if ($role != 2) {


      echo "<script> location.href='../accounts/accounts'; </script>";
        exit;


  }

}

if(isset($_POST['update']))
{

    $id =  $_REQUEST['id'];
        $username =  $_REQUEST['username'];
        $surname = $_REQUEST['surname'];
        $password = password_hash($_REQUEST['password'], PASSWORD_DEFAULT);
        $image = $_FILES["files"]["name"];
        $email =  $_REQUEST['email'];
        $phone = $_REQUEST['phone'];


        if (empty($_POST['username'])){

          $message1 = "Neįvestas vartotojo vardas!";

        }

        if (empty($_POST['surname'])){

          $message2 = "Neįvesta vartotojo pavardė!";

        }


        if (empty($_POST['password'])){

          $message3 = "Neįvestas slaptažodis!";

        }

        if (empty($_POST['verify-password'])){

          $message4 = "Neįvestas slaptažodžio pakartojimas!";

        }

        if ($_POST['verify-password'] != $_POST['password']){

          $message4 = "Slaptažodžiai nesutampa!";

        }

        if (!empty($_POST['role'])){

          if($_POST['role'] == 'Administratorius')
          {
             $role='1';
             mysqli_query($con,"UPDATE accounts set role='1' where id='$id'");
          }
          if($_POST['role'] == 'Vykdytojas')
          {
             $role='2';
             mysqli_query($con,"UPDATE accounts set role='2' where id='$id'");
          }
          if($_POST['role'] == 'Darbuotojas')
          {
             $role='3';
             mysqli_query($con,"UPDATE accounts set role='3' where id='$id'");
          }
          if($_POST['role'] == 'Nepriskirta')
          {
             $role='4';
             mysqli_query($con,"UPDATE accounts set role='4' where id='$id'");
          }


        }

        if (empty($_POST['email'])){

          $message6 = "Neįvestas el. paštas!";

        }

        if (!empty($_POST['email'])){

          $verificaion = mysqli_query($con, "SELECT email FROM accounts WHERE email = '".$email."'") or exit(mysqli_error($con));
          if(mysqli_num_rows($verificaion)) {

              $message6 = 'Paskyra su šiuo el. paštu jau egzistuoja!';

          }

        }

        if (empty($_POST['phone'])){

          $message7 = "Neįvestas telefonas!";

        }

        if (!empty($_POST['username']) && !empty($_POST['surname']) && !empty($_POST['verify-password']) && !empty($_POST['password']) && !empty($_POST['email']) && !empty($_POST['phone']) && $_POST['verify-password'] == $_POST['password']){

          $sql = "INSERT INTO accounts  VALUES ('','$username','$surname', '$password' ,'$email','$phone', '$role', '$image')";

          if(mysqli_query($con, $sql)){
          }
          else{
          }

          mysqli_close($con);

          echo "<script> location.href='../accounts/accounts'; </script>";
                  exit;

        }

}

?>

<head>
    <meta charset="UTF-8">
    <style>
    .sidebar{
      min-height: 125vh !important;
    }
    .ivedimas{
      width: 104%;
    }
    @media only screen and (max-width: 800px){

      .ivedimas{
        margin-bottom: 0px;
      }
    }

    </style>
</head>
<div class = "wrapper">
  <form method="POST" action="" class="card94" enctype="multipart/form-data" style='text-align: center'>
    <h2 style="color: black;">Naujo vartotojo registracija</h2>
    <br>
    <div class="row">

      <div class="column50" style="width: 92%; text-align: left" >
        <h4 class='punktas'>Vardas* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="username" id="username"  placeholder='<?php echo $message1; ?>'>
        <br>
        <h4 class='punktas'>Pavardė* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="surname" id="surname" placeholder='<?php echo $message2; ?>'>
        <br>
        <h4 class='punktas'>Slaptažodis* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="password" id="password" placeholder='<?php echo $message3; ?>'>
        <br>
        <h4 class='punktas'>Slaptažodžio patvirtinimas* </h4>
        <input class="ivedimas" autocomplete="off" type="text" name="verify-password" id="verify-password" placeholder='<?php echo $message4; ?>'>
        <br>
        <h4 class='punktas'>Pareigos* </h4>

        <?php
        if ($role == 1 ) {
          ?><select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
            <option value="Administratorius">Administratorius</option>
            <option value="Vykdytojas">Vykdytojas</option>
            <option value="Darbuotojas">Darbuotojas</option>
            <option value="Nepriskirta">Nepriskirta</option>
          </select><?php
        }
        else{
          ?>

          <select style='padding: 0px 16px 0px 16px !important;' class="ivedimas" type="text" name="role" id="role">
            <option value="Vykdytojas">Vykdytojas</option>
            <option value="Darbuotojas">Darbuotojas</option>
            <option value="Nepriskirta">Nepriskirta</option>
          </select>
          <?php

        }
         ?>
        <br>
        <h4 class='punktas'>El. Paštas* </h4>
        <input class="ivedimas" type="email" autocomplete="off" name="email" id="email" placeholder='<?php echo $message6; ?>'>
        <br>
        <h4 class='punktas'>Telefonas* </h4>
        <input style="margin-bottom: 2rem" autocomplete="off" class="ivedimas" type="text" name="phone" id="phone" placeholder='<?php echo $message7; ?>'>

      </div>

    </div>

        <button style='margin-bottom: 20px; margin-top: 20px' class="button" onclick="location.href='../accounts/accounts'" type='button'>Atšaukti</button>
        <button class="button" type="submit" name="update">Registruoti</button>

        <br>
        <br>

  </form>
</div>
